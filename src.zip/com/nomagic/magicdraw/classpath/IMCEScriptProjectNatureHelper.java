package com.nomagic.magicdraw.classpath;

import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

/**
 * @author Nicolas.F.Rouquette@jpl.nasa.gov
 *
 * Copyright 2012 Jet Propulsion Laboratory/Caltech
 */
public class IMCEScriptProjectNatureHelper {

	public static boolean hasProjectNature(IProject project) {
		if (null == project)
			throw new IllegalArgumentException("IMCEScriptProjectNatureHelper.hasProjectNature()");
		
		try {
			IProjectDescription description = project.getDescription();
			String[] natures = description.getNatureIds();

			for (int i = 0; i < natures.length; ++i) {
				if (IMCEScriptProjectNature.NATURE_ID.equals(natures[i]))
					return true;
			}
			return false;
			
		} catch (CoreException e) {
			throw new IllegalArgumentException("IMCEScriptProjectNatureHelper.hasProjectNature()", e);
		}
	}

	/**
	 * Toggles sample nature on a project
	 * 
	 * @param project
	 *            to have sample nature added or removed
	 * @throws CoreException 
	 */
	public static void toggleNature(IProject project) throws CoreException {
		IProjectDescription description = project.getDescription();
		String[] natures = description.getNatureIds();

		for (int i = 0; i < natures.length; ++i) {
			if (IMCEScriptProjectNature.NATURE_ID.equals(natures[i])) {
				// Remove the nature
				String[] newNatures = new String[natures.length - 1];
				System.arraycopy(natures, 0, newNatures, 0, i);
				System.arraycopy(natures, i + 1, newNatures, i, natures.length - i - 1);
				description.setNatureIds(newNatures);
				project.setDescription(description, null);
				return;
			}
		}

		// Add the nature
		String[] newNatures = new String[natures.length + 1];
		System.arraycopy(natures, 0, newNatures, 0, natures.length);
		newNatures[natures.length] = IMCEScriptProjectNature.NATURE_ID;
		description.setNatureIds(newNatures);
		project.setDescription(description, null);
	}

	public static void addNature(IProject project) throws CoreException {
		IProjectDescription description = project.getDescription();
		String[] natures = description.getNatureIds();

		for (int i = 0; i < natures.length; ++i) {
			if (IMCEScriptProjectNature.NATURE_ID.equals(natures[i])) {
				return;
			}
		}

		// Add the nature
		String[] newNatures = new String[natures.length + 1];
		System.arraycopy(natures, 0, newNatures, 0, natures.length);
		newNatures[natures.length] = IMCEScriptProjectNature.NATURE_ID;
		description.setNatureIds(newNatures);
		project.setDescription(description, null);
	}
		
	public static void removeNature(IProject project) throws CoreException {
		IProjectDescription description = project.getDescription();
		String[] natures = description.getNatureIds();

		for (int i = 0; i < natures.length; ++i) {
			if (IMCEScriptProjectNature.NATURE_ID.equals(natures[i])) {
				// Remove the nature
				String[] newNatures = new String[natures.length - 1];
				System.arraycopy(natures, 0, newNatures, 0, i);
				System.arraycopy(natures, i + 1, newNatures, i, natures.length - i - 1);
				description.setNatureIds(newNatures);
				project.setDescription(description, null);
				return;
			}
		}
	}
	
	public static IPath getScriptMagicDrawLocation(final IProject imcePluginsProject) {
		IPath mdInstallRoot = MDVariableInitializer.getMDInstallRootPath();
		if (mdInstallRoot.isEmpty())
			return null;
		final IPath imceScriptProjectLocation = mdInstallRoot.addTrailingSeparator().append("imce.scripts").addTrailingSeparator().append(imcePluginsProject.getName());
		return imceScriptProjectLocation;
	}
	
	public static void moveIMCEScriptsProjects(List<IProject> imceScriptsProjects) {
		for (IProject imceScriptsProject : imceScriptsProjects) {
			moveIMCEScriptsProject(imceScriptsProject);
		}
	}
	
	/**
	 * There should be a simpler way to do this...
	 * 
	 * @param imceScriptsProject the JPL MagicDraw Script-natured project to move to MD's install.root/imce.scripts folder
	 */
	public static void moveIMCEScriptsProject(final IProject imceScriptsProject) {
		IPath mdInstallRoot = MDVariableInitializer.getMDInstallRootPath();
		if (mdInstallRoot.isEmpty())
			return;
		IPath newIMCEScriptProjectLocation = getScriptMagicDrawLocation(imceScriptsProject);
		if (null == newIMCEScriptProjectLocation)
			return;
		IMCEProjectPropertyTester.moveProject(
				imceScriptsProject, 
				newIMCEScriptProjectLocation,
				"the ./imce.scripts folder in MD's install.root",
				mdInstallRoot);
	}
}
