package com.nomagic.magicdraw.classpath;

import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

/**
 * @author Nicolas.F.Rouquette@jpl.nasa.gov
 *
 * Copyright 2012 Jet Propulsion Laboratory/Caltech
 */
public class MagicDrawPluginProjectNatureHelper {

	public static boolean hasProjectNature(IProject project) {
		if (null == project)
			throw new IllegalArgumentException("IMCEPluginProjectNatureHelper.hasProjectNature()");
		
		try {
			IProjectDescription description = project.getDescription();
			String[] natures = description.getNatureIds();

			for (int i = 0; i < natures.length; ++i) {
				if (MagicDrawPluginProjectNature.NATURE_ID.equals(natures[i]))
					return true;
			}
			
			return false;
			
		} catch (CoreException e) {
			throw new IllegalArgumentException("IMCEPluginProjectNatureHelper.hasProjectNature()", e);
		}
	}

	/**
	 * Toggles sample nature on a project
	 * 
	 * @param project
	 *            to have sample nature added or removed
	 * @throws CoreException 
	 */
	public static void toggleNature(IProject project) throws CoreException {
		IProjectDescription description = project.getDescription();
		String[] natures = description.getNatureIds();

		for (int i = 0; i < natures.length; ++i) {
			if (MagicDrawPluginProjectNature.NATURE_ID.equals(natures[i])) {
				// Remove the nature
				String[] newNatures = new String[natures.length - 1];
				System.arraycopy(natures, 0, newNatures, 0, i);
				System.arraycopy(natures, i + 1, newNatures, i, natures.length - i - 1);
				description.setNatureIds(newNatures);
				project.setDescription(description, null);
				return;
			}
		}

		// Add the nature
		String[] newNatures = new String[natures.length + 1];
		System.arraycopy(natures, 0, newNatures, 0, natures.length);
		newNatures[natures.length] = MagicDrawPluginProjectNature.NATURE_ID;
		description.setNatureIds(newNatures);
		project.setDescription(description, null);
	}

	public static void addNature(IProject project) throws CoreException {
		IProjectDescription description = project.getDescription();
		String[] natures = description.getNatureIds();

		for (int i = 0; i < natures.length; ++i) {
			if (MagicDrawPluginProjectNature.NATURE_ID.equals(natures[i])) {
				return;
			}
		}

		// Add the nature
		String[] newNatures = new String[natures.length + 1];
		System.arraycopy(natures, 0, newNatures, 0, natures.length);
		newNatures[natures.length] = MagicDrawPluginProjectNature.NATURE_ID;
		description.setNatureIds(newNatures);
		project.setDescription(description, null);
	}
	
	public static void removeNature(IProject project) throws CoreException {
		IProjectDescription description = project.getDescription();
		String[] natures = description.getNatureIds();

		for (int i = 0; i < natures.length; ++i) {
			if (MagicDrawPluginProjectNature.NATURE_ID.equals(natures[i])) {
				// Remove the nature
				String[] newNatures = new String[natures.length - 1];
				System.arraycopy(natures, 0, newNatures, 0, i);
				System.arraycopy(natures, i + 1, newNatures, i, natures.length - i - 1);
				description.setNatureIds(newNatures);
				project.setDescription(description, null);
				return;
			}
		}
	}
	
	public static IPath getPluginMagicDrawLocation(final IProject imcePluginsProject) {
		IPath mdInstallRoot = MDVariableInitializer.getMDInstallRootPath();
		if (mdInstallRoot.isEmpty())
			return null;
		final IPath imcePluginProjectLocation = mdInstallRoot.addTrailingSeparator().append("plugins").addTrailingSeparator().append(imcePluginsProject.getName());
		return imcePluginProjectLocation;
	}
	
	public static void moveIMCEPluginsProjects(List<IProject> imcePluginsProjects) {
		for (IProject imcePluginsProject : imcePluginsProjects) {
			moveIMCEPluginsProject(imcePluginsProject);
		}
	}
	
	/**
	 * There should be a simpler way to do this...
	 * 
	 * @param imcePluginsProject the JPL MagicDraw Plugin-natured project to move to MD's install.root/imce.scripts folder
	 */
	public static void moveIMCEPluginsProject(final IProject imcePluginsProject) {
		IPath mdInstallRoot = MDVariableInitializer.getMDInstallRootPath();
		if (mdInstallRoot.isEmpty())
			return;
		IPath newIMCEPluginProjectLocation = getPluginMagicDrawLocation(imcePluginsProject);
		if (null == newIMCEPluginProjectLocation)
			return;
		IMCEProjectPropertyTester.moveProject(
				imcePluginsProject, 
				newIMCEPluginProjectLocation,
				"the ./plugins folder in MD's install.root",
				mdInstallRoot);
	}

}
