package com.nomagic.magicdraw.classpath;

import org.eclipse.ui.IStartup;

public class ActivationTriggerDummy implements IStartup {
	@Override
	public void earlyStartup() {
		// don't do anything at all
	}
}
