package com.nomagic.magicdraw.classpath.preferences;

/**
 * Constant definitions for plug-in preferences
 */
public class PreferenceConstants {

	public static final String MAGICDRAW_INSTALL_ROOT_PATH = "MagicDrawInstallRootPathPreference";

}
